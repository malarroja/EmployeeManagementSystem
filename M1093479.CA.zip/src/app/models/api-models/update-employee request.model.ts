export interface UpdateEmployeeRequest{
    name: string,
    dateOfBirth: string,
    mailID: string,
    phoneNumber: number,
    genderId: string,
    physicalAddress: string,
    postalAddress: string    
}